package com.rain.yuagent.constant;

/**
 * 文件路径常量
 */
public interface FileConstant {

    String FILE_SAVE_DIR = System.getProperty("user.dir") + "/tmp";

}
