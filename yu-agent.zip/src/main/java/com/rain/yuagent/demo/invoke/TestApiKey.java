package com.rain.yuagent.demo.invoke;

public interface TestApiKey {

    String API_KEY = "sk-62dd4720b27640d6a9ab3a5ff0fc6af4";

}
