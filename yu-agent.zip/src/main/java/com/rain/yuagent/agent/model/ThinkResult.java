package com.rain.yuagent.agent.model;

import lombok.Data;

@Data
public class ThinkResult {

    private Boolean isAct;
    private String thinkContent;

}
