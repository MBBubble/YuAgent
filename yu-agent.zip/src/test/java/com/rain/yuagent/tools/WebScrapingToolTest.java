package com.rain.yuagent.tools;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

import static org.junit.jupiter.api.Assertions.*;

@SpringBootTest
public class WebScrapingToolTest {

    @Test
    public void testScrapeWebPage() {
        WebScrapingTool tool = new WebScrapingTool();
        String url = "https://www.bt.cn/new/index.html";
        String result = tool.scrapeWebPage(url);
        System.out.println(result);
        assertNotNull(result);
    }
}
