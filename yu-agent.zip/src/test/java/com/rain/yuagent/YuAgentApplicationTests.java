package com.rain.yuagent;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class YuAgentApplicationTests {

    @Test
    void contextLoads() {
    }

}
